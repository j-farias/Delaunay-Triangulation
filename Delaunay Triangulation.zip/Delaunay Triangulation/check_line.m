function [notline] = check_line(c1, c2, c3, c4, c5, c6)

%check to see if the area of the triangle formed by these points is = 0. If
%it is these points from a line
if c1 * (c4 - c6) + c3 * (c6 - c2) + c5 * (c2 - c4) == 0
    notline = false;
else
    notline = true;
end

end