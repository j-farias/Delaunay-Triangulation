function [] = plot_delaunay(triangles)
    for i = 1:length(triangles)
        t = triangles(:,:,i);
        plot([t(1,1,:) t(2,1,:) t(3,1,:) t(1,1,:)], [t(1,2,:) t(2,2,:) ...
            t(3,2,:) t(1,2,:)]);
        hold on
    end
    hold off
end