function [p, q, d, notline] = center_point(x, y)
   
   %create convenient coordinate points
   c1 = x(1);
   c2 = y(1);
   c3 = x(2);
   c4 = y(2);
   c5 = x(3);
   c6 = y(3);
   
   %create symbolic variables, in this case x represents p and y 
   %represents q. eqn represents 0 essentially
   syms x y eqn
   notline = check_line(c1, c2, c3, c4, c5, c6);
   
   if notline == true
   %we dont want a divide by 0 error. this is the case were the x
   %coordinates of 2 points are the same
       if (c3 - c1 ~= 0)
           %use distance relations to put x (p) in terms of y (q) 
           x= (-2*y*c4 + 2*y*c2 - c2^2 + c4^2 - c1^2 + c3^2)/(2*c3 - 2*c1);
           %now plug this x into a second distance relation and set one 
           %side equal to 0
           eqn = -2*c1*x + c1^2 - 2*y*c2 + c2^2 + 2*c5*x - c5^2 - c6^2 ...
               + 2*y*c6;
           %we solve the 0s of eqn, which = 0, to find y
           notline = true; 

           q = solve(eqn, y);
           %now that we have q we can solve for p easily
           p= (-2*q*c4 + 2*q*c2 - c2^2 + c4^2 - c1^2 + c3^2)/(2*c3 - 2*c1);

       %check other case
       elseif (c3 - c5 ~= 0)

           x= (-2*y*c4 + 2*y*c6 - c6^2 + c4^2 - c5^2 + c3^2)/(2*c3 - 2*c5);
           eqn= -2*c5*x + c5^2 - 2*y*c6 + c6^2 + 2*c1*x - c1^2 - c2^2 ...
               + 2*y*c2;
           notline = true;

           q = solve(eqn, y);
           %now that we have q we can solve for p easily
           p= (-2*q*c4 + 2*q*c6 - c6^2 + c4^2 - c5^2 + c3^2)/(2*c3 - 2*c5);

       %check last case
       elseif (c5 - c1 ~= 0)

           x= (-2*y*c6 + 2*y*c2 - c2^2 + c6^2 - c1^2 + c5^2)/(2*c5 - 2*c1);
           eqn= -2*c1*x + c1^2 - 2*y*c2 + c2^2 + 2*c3*x - c3^2 - c4^2 ...
               + 2*y*c4;
           notline = true;

           q = solve(eqn, y);
           %now that we have q we can solve for p easily
           p= (-2*q*c6 + 2*q*c2 - c2^2 + c6^2 - c1^2 + c5^2)/(2*c5 - 2*c1);

       %this is the case that the three x-coordinates are the same
       end
       
   else
       q = 0;
       p = 0;
       notline = false;
   end
   
   %solve for distance between the center and any coordinate
   d = sqrt((p - c1)^2 + (q - c2)^2);

end