run the test function to see the delaunay plot. You can edit the x and y lists to alter the coordinates. 
