%center_point([0 0;2 0; 1 1.701]);
x = [0 4 6 2 7 -1 -12 13 14 15];
y = [2 4 2 5 2 -3 -1 12 13 14];

triangles = triangulate(x, y);
%[p q d] = center_point([0 1;3 5; -6 -7])

plot_delaunay(triangles);