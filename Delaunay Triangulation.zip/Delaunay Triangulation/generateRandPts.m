function [pts] = generateRandPts(x, y, num)

pts = zeros(num, 2);

minX = min(x);
maxX = max(x);
minY = min(y);
maxY = max(y);

i = 1;

while i <= num
    randX = minX + (maxX - minX).*rand;
    randY = minY + (maxY - minY).*rand;
    
    [in, on] = inpolygon(randX, randY, x, y);
    
    if in && ~on
        pts(i, 1) = randX;
        pts(i, 2) = randY;
        i = i + 1;
    end
end

end