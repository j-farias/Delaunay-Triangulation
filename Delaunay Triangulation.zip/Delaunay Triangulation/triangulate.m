function [triangles] = triangulate(x, y)
    triangles = [];
    triangle_count = 1;

    %We iterate through every combination of three coordinates
    for i = 1:length(x)
        for j = 1:length(x)
            for k = 1:length(x)
                
                %we dont want to check repeated coordinates
                if j > i && k > i + 1 
                    
                    istriangle = true;
                    %now iteralte through and compare each coordinate
                    %to the cicle created by i j and k
                    for m = 1:length(x)
                        if m ~= i && m ~= j && m ~= k

                            [p, q, d, notline] = center_point([x(i) ...
                                x(j) x(k)], [y(i) y(j) y(k)]);                                ...
                                 
                            
                            %check if there are any other points inside
                            %circle or if the three points form a line (no
                            %circle)
                            if sqrt((p - x(m))^2 +...
                                    (q - y(m))^2) < d || ~notline
                                istriangle = false;
                                break
                            end
                        end
                    end
                    
                    %if its a valid triangle add it to the 3D array
                    if istriangle
                        triangles(:,:,triangle_count) = ...
                            [x(i) y(i);...
                                x(j) y(j);...
                                x(k) y(k)];
                        triangle_count = triangle_count + 1;
                    end
                end
            end
        end
    end   
end