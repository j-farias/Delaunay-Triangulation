function [triangles] = triangulation([coords])
    
    %We iterate through every combination of three coordinates
    for i = 1:length(coords)
        for j = 1:length(coords)
            for k = l:length(coords)
                if i ~= j && i ~= k && j ~= k
                    
                    istriangle = true;
                    
                    for m = 1:length(coords)
                        if m ~= i && m ~= j && m ~= k
                            [p, q, d] = center_point( ...
                                [coords(i, 1) coords(i, 2);...
                                coords(j, 1) coords(j, 2);...
                                coords(k, 1) coords(k, 2)]);
                            
                            if sqrt((p - coords(m, 1))^2 +...
                                    (q - coords(m, 2))^2) < d
                                istriangle = false;
                            end
                        end
                    end
                    
                    if istriangle
                        triangles = [triangles, [(coords(i, 1)...
                            coords(i, 2);...
                            coords(j, 1) coords(j, 2);...
                            coords(k, 1) coords(k, 2)]);
                    end
                end
            end
        end
    end                             
end